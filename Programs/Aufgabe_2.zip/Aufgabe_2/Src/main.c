/**
  ******************************************************************************
  * @file    main.c
  * @author  Franz Korf
  * @brief   Kleines Testprogramm fuer neu erstelle Fonts.
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/

#include "LCD_general.h"
#include "errors.h"
#include "fonts.h"
#include "led.h"
#include "output.h"
#include "stm32f429xx.h"
#include "stm32f4xx_hal.h"
#include "init.h"
#include "LCD_GUI.h"
#include "LCD_Touch.h"
#include "lcd.h"
#include "fontsFLASH.h"
#include "additionalFonts.h"
#include "error.h"
#include "gpio.h"
#include "taster.h"
#include <stdbool.h>
#include "terminal.h"


int main(void) {
	initITSboard();    // Initialisierung des ITS Boards
	
	GUI_init(DEFAULT_BRIGHTNESS);   // Initialisierung des LCD Boards mit Touch
	TP_Init(false);                 // Initialisierung des LCD Boards mit Touch

	/*
	// Test in Endlosschleife
	while(1) {
		//Input
		int phase;

		//Berechnung


	}*/

	initLayout();
	printError("Hello World");
	return EOK;
}

// EOF
